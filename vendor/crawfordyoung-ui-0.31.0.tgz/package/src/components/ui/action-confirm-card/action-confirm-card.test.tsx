import { describe, it, expect, vi } from 'vitest'
import { render, screen, fireEvent } from '@testing-library/react'
import { ActionConfirmCard } from './action-confirm-card'

describe('ActionConfirmCard', () => {
  const baseProps = {
    action: "Mark 'Morning Run' complete",
    entityType: 'habit' as const,
    date: 'June 1st',
    time: '7:00 AM',
    onConfirm: vi.fn(),
    onDeny: vi.fn(),
  }

  it('renders action text', () => {
    render(<ActionConfirmCard {...baseProps} />)
    expect(screen.getByText("Mark 'Morning Run' complete")).toBeInTheDocument()
  })

  it('renders date and time', () => {
    render(<ActionConfirmCard {...baseProps} />)
    expect(screen.getByText(/June 1st/)).toBeInTheDocument()
    expect(screen.getByText(/7:00 AM/)).toBeInTheDocument()
  })

  it('renders entity type badge', () => {
    render(<ActionConfirmCard {...baseProps} />)
    expect(screen.getByText('habit')).toBeInTheDocument()
  })

  it('calls onConfirm when checkmark clicked', () => {
    const onConfirm = vi.fn()
    render(<ActionConfirmCard {...baseProps} onConfirm={onConfirm} />)
    fireEvent.click(screen.getByRole('button', { name: /confirm/i }))
    expect(onConfirm).toHaveBeenCalledOnce()
  })

  it('reveals reason input when X clicked', () => {
    render(<ActionConfirmCard {...baseProps} />)
    fireEvent.click(screen.getByRole('button', { name: /deny/i }))
    expect(screen.getByPlaceholderText(/why not/i)).toBeInTheDocument()
  })

  it('cancel hides reason input', () => {
    render(<ActionConfirmCard {...baseProps} />)
    fireEvent.click(screen.getByRole('button', { name: /deny/i }))
    fireEvent.click(screen.getByRole('button', { name: /cancel/i }))
    expect(screen.queryByPlaceholderText(/why not/i)).not.toBeInTheDocument()
  })

  it('calls onDeny with reason when Send clicked', () => {
    const onDeny = vi.fn()
    render(<ActionConfirmCard {...baseProps} onDeny={onDeny} />)
    fireEvent.click(screen.getByRole('button', { name: /deny/i }))
    fireEvent.change(screen.getByPlaceholderText(/why not/i), {
      target: { value: 'wrong date' },
    })
    fireEvent.click(screen.getByRole('button', { name: /send/i }))
    expect(onDeny).toHaveBeenCalledWith('wrong date')
  })

  it('calls onDeny with empty string when Send clicked without reason', () => {
    const onDeny = vi.fn()
    render(<ActionConfirmCard {...baseProps} onDeny={onDeny} />)
    fireEvent.click(screen.getByRole('button', { name: /deny/i }))
    fireEvent.click(screen.getByRole('button', { name: /send/i }))
    expect(onDeny).toHaveBeenCalledWith('')
  })

  it('shows confirmed state after confirm', () => {
    render(<ActionConfirmCard {...baseProps} />)
    fireEvent.click(screen.getByRole('button', { name: /confirm/i }))
    expect(screen.getByText(/confirmed/i)).toBeInTheDocument()
    expect(screen.queryByRole('button', { name: /confirm/i })).not.toBeInTheDocument()
  })

  it('shows denied state after deny + send', () => {
    render(<ActionConfirmCard {...baseProps} />)
    fireEvent.click(screen.getByRole('button', { name: /deny/i }))
    fireEvent.click(screen.getByRole('button', { name: /send/i }))
    expect(screen.getByText(/declined/i)).toBeInTheDocument()
    expect(screen.queryByRole('button', { name: /deny/i })).not.toBeInTheDocument()
  })

  it('renders without time for goal entity type', () => {
    render(
      <ActionConfirmCard
        action="Create goal 'Write book'"
        entityType="goal"
        date="December 31st"
        onConfirm={vi.fn()}
        onDeny={vi.fn()}
      />,
    )
    expect(screen.getByText('December 31st')).toBeInTheDocument()
    expect(screen.queryByText(/7:00 AM/)).not.toBeInTheDocument()
  })

  it('renders event entity type badge with green styling', () => {
    render(
      <ActionConfirmCard
        action="Team standup"
        entityType="event"
        date="June 3rd"
        time="9:00 AM"
        onConfirm={vi.fn()}
        onDeny={vi.fn()}
      />,
    )
    expect(screen.getByText('event')).toBeInTheDocument()
  })

  it('renders activity entity type badge', () => {
    render(
      <ActionConfirmCard
        action="Log 'Morning run'"
        entityType="activity"
        date="June 3rd"
        time="7:00 AM"
        onConfirm={vi.fn()}
        onDeny={vi.fn()}
      />,
    )
    expect(screen.getByText('activity')).toBeInTheDocument()
  })

  it('renders detail text when detail prop is provided', () => {
    render(<ActionConfirmCard {...baseProps} detail="Streak: 7 days" />)
    expect(screen.getByText('Streak: 7 days')).toBeInTheDocument()
  })
})
