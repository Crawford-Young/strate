import tailwindAnimate from 'tailwindcss-animate'
import type { Config } from 'tailwindcss'
import { SHIMMER_PERIOD_MS } from '../lib/motion'

export const cyUIPreset: Partial<Config> = {
  darkMode: 'class',
  theme: {
    extend: {
      colors: {
        background: 'rgb(var(--background) / <alpha-value>)',
        foreground: 'rgb(var(--foreground) / <alpha-value>)',
        surface: {
          DEFAULT: 'rgb(var(--surface) / <alpha-value>)',
          raised: 'rgb(var(--surface-raised) / <alpha-value>)',
        },
        border: 'rgb(var(--border) / <alpha-value>)',
        input: 'rgb(var(--input) / <alpha-value>)',
        ring: 'rgb(var(--ring) / <alpha-value>)',
        muted: {
          DEFAULT: 'rgb(var(--muted) / <alpha-value>)',
          foreground: 'rgb(var(--muted-foreground) / <alpha-value>)',
        },
        accent: {
          DEFAULT: 'rgb(var(--accent) / <alpha-value>)',
          foreground: 'rgb(var(--accent-foreground) / <alpha-value>)',
          hover: 'rgb(var(--accent-hover) / <alpha-value>)',
          'hover-foreground': 'rgb(var(--accent-hover-foreground) / <alpha-value>)',
          subtle: 'rgb(var(--accent-subtle) / <alpha-value>)',
          'subtle-foreground': 'rgb(var(--accent-subtle-foreground) / <alpha-value>)',
          active: 'rgb(var(--accent-active) / <alpha-value>)',
          'active-foreground': 'rgb(var(--accent-active-foreground) / <alpha-value>)',
        },
        destructive: {
          DEFAULT: 'rgb(var(--destructive) / <alpha-value>)',
          foreground: 'rgb(var(--destructive-foreground) / <alpha-value>)',
        },
        success: {
          DEFAULT: 'rgb(var(--success) / <alpha-value>)',
          foreground: 'rgb(var(--success-foreground) / <alpha-value>)',
        },
        warning: {
          DEFAULT: 'rgb(var(--warning) / <alpha-value>)',
          foreground: 'rgb(var(--warning-foreground) / <alpha-value>)',
        },
        info: {
          DEFAULT: 'rgb(var(--info) / <alpha-value>)',
          foreground: 'rgb(var(--info-foreground) / <alpha-value>)',
        },
        // Categorical series, cycled by StackedBarChart and DayTimeline
        chart: {
          1: 'rgb(var(--chart-1) / <alpha-value>)',
          2: 'rgb(var(--chart-2) / <alpha-value>)',
          3: 'rgb(var(--chart-3) / <alpha-value>)',
          4: 'rgb(var(--chart-4) / <alpha-value>)',
          5: 'rgb(var(--chart-5) / <alpha-value>)',
          6: 'rgb(var(--chart-6) / <alpha-value>)',
        },
        'item-hover': 'rgb(var(--item-hover) / <alpha-value>)',
        // Semantic aliases used by component CVA variants
        primary: {
          DEFAULT: 'rgb(var(--accent) / <alpha-value>)',
          foreground: 'rgb(var(--accent-foreground) / <alpha-value>)',
        },
        secondary: {
          DEFAULT: 'rgb(var(--surface-raised) / <alpha-value>)',
          foreground: 'rgb(var(--foreground) / <alpha-value>)',
        },
        card: {
          DEFAULT: 'rgb(var(--surface) / <alpha-value>)',
          foreground: 'rgb(var(--foreground) / <alpha-value>)',
        },
        popover: {
          DEFAULT: 'rgb(var(--surface) / <alpha-value>)',
          foreground: 'rgb(var(--foreground) / <alpha-value>)',
        },
      },
      borderRadius: {
        sm: 'var(--radius-sm)',
        DEFAULT: 'var(--radius)',
        lg: 'var(--radius-lg)',
        xl: 'var(--radius-xl)',
        full: 'var(--radius-full)',
      },
      fontFamily: {
        sans: ['var(--font-sans)', 'system-ui', 'sans-serif'],
        mono: ['var(--font-mono)', 'ui-monospace', 'monospace'],
      },
      transitionDuration: {
        instant: 'var(--motion-instant)',
        fast: 'var(--motion-fast)',
        base: 'var(--motion-base)',
        slow: 'var(--motion-slow)',
        hero: 'var(--motion-hero)',
      },
      // 'out' and 'in-out' intentionally shadow Tailwind's built-in ease-out / ease-in-out with brand curves
      transitionTimingFunction: {
        out: 'var(--ease-out)',
        'in-out': 'var(--ease-in-out)',
        exit: 'var(--ease-exit)',
      },
      keyframes: {
        'draw-check': {
          to: { strokeDashoffset: '0' },
        },
        'radio-dot': {
          from: { transform: 'scale(0)', opacity: '0' },
          to: { transform: 'scale(1)', opacity: '1' },
        },
        'switch-thumb': {
          '50%': { scale: '1.1' },
        },
        'progress-indeterminate': {
          '0%': { transform: 'translateX(-100%)', opacity: '1' },
          '50%': { opacity: '0.6' },
          '100%': { transform: 'translateX(100%)', opacity: '1' },
        },
        'accordion-down': {
          from: { height: '0' },
          to: { height: 'var(--radix-accordion-content-height)' },
        },
        'accordion-up': {
          from: { height: 'var(--radix-accordion-content-height)' },
          to: { height: '0' },
        },
        'collapsible-down': {
          from: { height: '0' },
          to: { height: 'var(--radix-collapsible-content-height)' },
        },
        'collapsible-up': {
          from: { height: 'var(--radix-collapsible-content-height)' },
          to: { height: '0' },
        },
        shimmer: {
          from: { transform: 'translateX(-100%)' },
          to: { transform: 'translateX(100%)' },
        },
        trace: {
          to: { strokeDashoffset: '-100' },
        },
        'brand-enter': {
          from: { opacity: '0', transform: 'translateY(8px) scale(0.96)' },
          to: { opacity: '1', transform: 'translateY(0) scale(1)' },
        },
        'trace-dot': {
          '0%, 100%': { opacity: '0.4' },
          '50%': { opacity: '1' },
        },
      },
      animation: {
        'draw-check': 'draw-check 150ms var(--ease-out) forwards',
        'radio-dot': 'radio-dot 120ms var(--ease-out)',
        shimmer: `shimmer ${SHIMMER_PERIOD_MS}ms var(--ease-in-out) infinite`,
        'switch-thumb': 'switch-thumb 200ms var(--ease-in-out)',
        'progress-indeterminate': 'progress-indeterminate 1.4s var(--ease-in-out) infinite',
        'accordion-down': 'accordion-down 200ms var(--ease-out)',
        'accordion-up': 'accordion-up 200ms var(--ease-out)',
        'collapsible-down': 'collapsible-down 200ms var(--ease-out)',
        'collapsible-up': 'collapsible-up 200ms var(--ease-out)',
        trace: 'trace 1.2s var(--ease-in-out) infinite',
        'trace-dot': 'trace-dot 1s ease-in-out infinite',
        'brand-enter': 'brand-enter 400ms var(--ease-out) both',
      },
    },
  },
  plugins: [tailwindAnimate],
}
